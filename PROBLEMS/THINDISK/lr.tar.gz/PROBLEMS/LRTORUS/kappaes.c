//scattering

return  kappaCGS2GU(0.34)*rho;

